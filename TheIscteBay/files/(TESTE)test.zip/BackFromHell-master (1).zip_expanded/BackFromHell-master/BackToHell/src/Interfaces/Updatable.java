package Interfaces;

public interface Updatable {

	void update();
	
}
