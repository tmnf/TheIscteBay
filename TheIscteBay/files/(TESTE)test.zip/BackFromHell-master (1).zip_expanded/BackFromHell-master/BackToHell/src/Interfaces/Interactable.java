package Interfaces;

import MainGame.GameObject;

public interface Interactable {

	void activatedBy(GameObject x);

}
