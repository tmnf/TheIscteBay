package Enums;

public enum State {

	Menu(), Game(), Pause(), Loading();

}
