package Enums;

public enum ID {

	Player(),
	Tile(),
	Entities(),
	Empty();

}
